import datetime
from geopy import distance

class EarthQuake:
    
    # Constants for computing influence domain (found by trial and error)
    A1 = 0.4486892  # 0.3486892 
    B1 = -0.0758295
    A2 = 0.3053087 # 0.2053087
    B2 = 1.262296
    
    def __init__(self, id:str, date:datetime, lat : float, long : float, mag : float):
        self.id = id
        self.date = date
        self.lat = lat 
        self.long = long
        self.mag = mag
    
    # Returns the distance difference (in km) between the current and the other earthquake
    def distance_to(self, e : 'EarthQuake'):
        return distance.geodesic((self.lat, self.long), (e.lat, e.long)).kilometers
    
    # Returns the time difference (in hours) between the current and the other earthquake
    def time_diff(self, e : 'EarthQuake'):
        if e.date < self.date :
            return -1
        
        return ((e.date - self.date).total_seconds()) / 3600;
    
    # Validates whether the passed earthquake is in the influence domain of the current Earthquake
    def is_in_influence_domain(self, e : 'EarthQuake')  :
        
        dist = self.distance_to(e) # km
        time_diff = self.time_diff(e) # hours
                    
        if time_diff == -1: 
            return False
        
        influence_dist = 10 ** (self.A1 * self.mag + self.B1)
        influence_time = 10 ** (self.A2 * self.mag + self.B2)

        return (influence_dist >= dist) and (influence_time >= time_diff)