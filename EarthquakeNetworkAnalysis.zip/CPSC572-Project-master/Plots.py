from enum import Enum
import matplotlib as mpl
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import poisson
import powerlaw

class Style(Enum):
    One = 1
    Two = 2
    
class Fit(Enum):
    Poisson=1
    PowerLaw=2
    
class Plots:
    
    # Colors 
    BLUE = '#004777'
    RED = '#a30000'
     
    # Styles for plots 
    @classmethod
    def set_plot_styles_one(cls):  # Used to format plots
        mpl.rc('xtick', labelsize=16, color="#222222")
        mpl.rc('ytick', labelsize=16, color="#222222")
        mpl.rc('font', **{'family': 'sans-serif', 'sans-serif': ['Arial']})
        mpl.rc('font', size=16)
        mpl.rc('xtick.major', size=10, width=1)
        mpl.rc('xtick.minor', size=12, width=1)
        mpl.rc('ytick.major', size=10, width=1)
        mpl.rc('ytick.minor', size=12, width=1)
        mpl.rc('axes', linewidth=2, edgecolor="#222222", labelcolor="#222222")
        mpl.rc('text', usetex=False, color="#222222")
     
    # Methods 
    
    @classmethod
    def plot_deg_dist_undirected(cls, G, img_path=None, fit=None, style=Style.One): # G must be a undirected network as the plot does NOT consider in and out degrees
       
        # Setting style for plot
        if style == Style.One:
            cls.set_plot_styles_one()
        else: pass 

        # Setting up plot
        degrees = [G.degree(n) for n in G.nodes()]
        kmin = min(degrees)
        kmax = max(degrees)

        if kmin > 0:
            bin_edges = np.logspace(np.log10(kmin), np.log10(kmax) + 1, num=20)
        else:
            bin_edges = np.logspace(0, np.log10(kmax) + 1, num=20)
        density, _ = np.histogram(degrees, bins=bin_edges, density=True)

        fig = plt.figure(figsize=(8, 7))

        log_be = np.log10(bin_edges)
        x = 10 ** ((log_be[1:] + log_be[:-1]) / 2)
        plt.loglog(x, density, marker='o', linestyle='none', markersize=8, color=cls.BLUE)
        plt.title("Degree Distribution")
        plt.xlabel(r"degree $k$", fontsize=12)
        plt.ylabel(r"$P(k)$", fontsize=12)

        ax = plt.gca()
        ax.spines['right'].set_visible(False)
        ax.spines['top'].set_visible(False)
        ax.yaxis.set_ticks_position('left')
        ax.xaxis.set_ticks_position('bottom')

        if fit == Fit.Poisson:
            k = np.arange(kmin, kmax)
            pmf = poisson.pmf(k, k.mean())
            plt.plot(k, pmf, color='red')

        else:
            # plot theoretical fit. https://pypi.org/project/powerlaw/
            fit_in = powerlaw.Fit(degrees, xmin=1, xmax=max(degrees))
            fit_in.power_law.plot_pdf(color='red')

        plt.show()

        if img_path: fig.savefig(img_path)
    
    @classmethod
    def plot_deg_dist_directed(cls, G, img_path=None, fit=None, style=Style.One):  # G must be a directed network as the plot considers in and out degrees

        # Setting style for plot
        if style == Style.One:
            cls.set_plot_styles_one()
        else: pass 

        # Setting up plot
        degrees = [G.degree(n) for n in G.nodes()]
        in_degrees = [G.in_degree(n) for n in G.nodes()]
        out_degrees = [G.out_degree(n) for n in G.nodes()]
        in_kmin = min(in_degrees)
        in_kmax = max(in_degrees)
        out_kmin = min(out_degrees)
        out_kmax = max(out_degrees)

        if in_kmin > 0:
            bin_edges = np.logspace(np.log10(in_kmin), np.log10(in_kmax) + 1, num=20)
        else:
            bin_edges = np.logspace(0, np.log10(in_kmax) + 1, num=20)
        in_density, _ = np.histogram(in_degrees, bins=bin_edges, density=True)

        if out_kmin > 0:
            bin_edges = np.logspace(np.log10(out_kmin), np.log10(out_kmax) + 1, num=20)
        else:
            bin_edges = np.logspace(0, np.log10(out_kmax) + 1, num=20)
        out_density, _ = np.histogram(out_degrees, bins=bin_edges, density=True)

        fig = plt.figure(figsize=(8, 7))

        log_be = np.log10(bin_edges)
        x = 10 ** ((log_be[1:] + log_be[:-1]) / 2)
        plt.loglog(x, in_density, marker='o', linestyle='none', markersize=8, color=cls.BLUE, label='in-degree')
        plt.loglog(x, out_density, marker='o', linestyle='none', markersize=8, color=cls.RED, label='out-degree')
        plt.title("Degree Distribution")
        plt.xlabel(r"degree $k$", fontsize=12)
        plt.ylabel(r"$P(k)$", fontsize=12)
        plt.legend(loc="best")

        ax = plt.gca()
        ax.spines['right'].set_visible(False)
        ax.spines['top'].set_visible(False)
        ax.yaxis.set_ticks_position('left')
        ax.xaxis.set_ticks_position('bottom')

        if fit == Fit.Poisson:
            kmin = (in_kmin + out_kmin) / 2
            kmax = (in_kmax + out_kmax) / 2
            k = np.arange(kmin, kmax)
            pmf = poisson.pmf(k, k.mean()/2)
            plt.plot(k, pmf, color='red')

        else:
            # plot theoretical fit. https://pypi.org/project/powerlaw/
            fit_in = powerlaw.Fit(degrees, xmin=1, xmax=max(degrees))
            fit_in.power_law.plot_pdf(color='red')

        plt.show()

        if img_path: fig.savefig(img_path)

    # @classmethod
    # def plot_circular_layout(cls, G):
    #     # EarthQuakeGraph._set_plot_style()
    #     plt.figure(figsize=(8, 8))
    #     nx.draw_circular(G, node_size=40)

    # @classmethod
    # def plot_spring_layout(cls, G):
    #     # EarthQuakeGraph._set_plot_style()
    #     plt.figure(figsize=(8, 8))
    #     nx.draw_spring(G, node_size=40)

