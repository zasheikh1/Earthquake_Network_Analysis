from DataProcessor import DataProcessor
from EarthQuakeGraph import EarthQuakeGraph
from NullModels import NullModels
from Plots import Fit, Plots
from Stats import Stats

# Constants

    # Input/Output files for network creation

INPUT_RAW_CSV = './input/input.csv'
OUTPUT_NODES_CSV = './output/csv/nodes.csv'
OUTPUT_EDGES_CSV = './output/csv/edges.csv'

    # Stats
EARTHQUAKE_STATS_DIRECTED = './output/stats/earthquake_directed_network_stats.csv'
EARTHQUAKE_STATS_UNDIRECTED = './output/stats/earthquake_undirected_network_stats.csv'

    # Null Models
    
RANDOM_STATS = './output/stats/random_network_stats.csv'
DEG_PRESERVING_RAND_STATS = './output/stats/deg_preserving_rand_network_stats.csv'
RANDOM_GEOMETRIC_STATS = './output/stats/random_geometric_network_stats.csv'
ERODOS_RENYI_RANDOM_STATS = './output/stats/erodos_renyi_network_stats.csv'

    # Research Questions

    #1

    #2

    #3
SPECIFIC_MAG_CSV = './output/csv/domino_degrees.csv'
SPECIFIC_MAG_FIG = './output/images/domino_degrees.png'
ER_SPECIFIC_MAG_CSV = './output/csv/domino_degrees_erNull.csv'
ER_SPECIFIC_MAG_FIG = './output/images/domino_degrees_erNull.png'
RG_SPECIFIC_MAG_CSV = './output/csv/domino_degrees_rgNull.csv'
RG_SPECIFIC_MAG_FIG = './output/images/domino_degrees_rgNull.png'

    # Others (Helpers)
NODES_AND_UMT_CSV = './output/csv/nodes_in_umt.csv'
AVG_EUCLIDEAN_DIST = './output/csv/avg_euclidean_dist.csv'

    # Plots
EARTHQUAKE_DEG_DIST_DIRECTED = './output/images/earthquake_deg_dist_directed.png'
EARTHQUAKE_DEG_DIST_UNDIRECTED = './output/images/earthquake_deg_dist_undirected.png'

RAND_DEG_DIST = './output/images/rand_deg_network_dist.png'
RAND_DEG_DIST_DIRECTED = './output/images/rand_deg_network_dist_directed.png'
DEG_PRESERVING_RAND_DEG_DIST = './output/images/deg_preserving_rand_network_deg_dist.png'
RANDOM_GEOMETRIC_DEG_DIST = './output/images/random_geometric_network_deg_dist.png'

#------------------------------------------------------

# Reading raw data and converting it to a format ready to create a graph from.
nodes_df, edges_df = DataProcessor.df_from_csv(INPUT_RAW_CSV, OUTPUT_NODES_CSV, OUTPUT_EDGES_CSV)

#######-- Creating Graph (to get stats) --#######
directed_graph = EarthQuakeGraph.create_graph(nodes_df, edges_df)
undirected_graph = EarthQuakeGraph.create_graph(nodes_df, edges_df, is_undirected=True)

#######-- Network General Stats (directed and undirected) --#######
# Stats.from_directed_network(directed_graph).to_csv(EARTHQUAKE_STATS_DIRECTED, True)
# Stats.from_undirected_network(undirected_graph).to_csv(EARTHQUAKE_STATS_UNDIRECTED, False)

# Research Questions

    #1
# EarthQuakeGraph.plot_outdeg_vs_magnitude(EarthQuakeGraph.compute_outdeg_and_maginute(directed_graph))
# EarthQuakeGraph.plot_avg_clustering_coeff_vs_magnitude(EarthQuakeGraph.compute_outdeg_and_avg_clustering_coeff(directed_graph))

    #2

    #3
# EarthQuakeGraph.nodes_with_specific_magnitude(directed_graph, SPECIFIC_MAG_CSV, SPECIFIC_MAG_FIG)

# Null Models

node_info = EarthQuakeGraph.get_node_info(OUTPUT_NODES_CSV)

    # Random Network (ER)
# er_network = NullModels.er_network(directed_graph, node_info)
# NullModels.er_network_stats(directed_graph,ERODOS_RENYI_RANDOM_STATS, node_info)

    # Degree Preserving Random Network
# dp_network = NullModels.dp_network([undirected_graph.degree(n) for n in undirected_graph.nodes()], DEG_PRESERVING_RAND_STATS, one_network=True)

    # Random Geometric Network
# edge_list = EarthQuakeGraph.get_edge_list(directed_graph)
#
# utm_dict_no_id, utm_dict_with_id = EarthQuakeGraph.to_umt(directed_graph, NODES_AND_UMT_CSV)
# avg_euclidean_dist = EarthQuakeGraph.avg_euclidean_dist(directed_graph, utm_dict_with_id, AVG_EUCLIDEAN_DIST)
# NullModels.rg_network_stats(directed_graph.number_of_nodes(), 
#                             avg_euclidean_dist, 
#                             utm_dict_no_id, 
#                             RANDOM_GEOMETRIC_STATS,
#                             node_info,
#                             edge_list)

# rg_network = NullModels.rg_network(directed_graph.number_of_nodes(), avg_euclidean_dist, utm_dict_no_id, node_info, edge_list)

# for node in rg_network.nodes(data=True):
#     print(node)

#######-- Plots --#######
# Plots.plot_deg_dist_directed(directed_graph, EARTHQUAKE_DEG_DIST_DIRECTED)
# Plots.plot_deg_dist_directed(er_network, RAND_DEG_DIST_DIRECTED, fit=Fit.Poisson)
# Plots.plot_deg_dist_directed(rg_network, RANDOM_GEOMETRIC_DEG_DIST)

# Plots.plot_deg_dist_undirected(undirected_graph, EARTHQUAKE_DEG_DIST_UNDIRECTED)
# Plots.plot_deg_dist_undirected(er_network, RAND_DEG_DIST, fit=Fit.Poisson)
# Plots.plot_deg_dist_undirected(dp_network, DEG_PRESERVING_RAND_DEG_DIST)
# Plots.plot_deg_dist_undirected(rg_network, RANDOM_GEOMETRIC_DEG_DIST)

#######-- NULL MODEL COMPARISON --#######
# EarthQuakeGraph.nodes_with_specific_magnitude(er_network, ER_SPECIFIC_MAG_CSV, ER_SPECIFIC_MAG_FIG)
# EarthQuakeGraph.nodes_with_specific_magnitude(rg_network, RG_SPECIFIC_MAG_CSV, RG_SPECIFIC_MAG_FIG)
