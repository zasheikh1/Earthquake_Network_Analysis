import networkx as nx
import numpy as np
import pandas as pd

class Stats:
    
    def __init__(self, number_of_nodes=0, 
                       number_of_edges=0, 
                       avg_degree=0, 
                       max_degree=0, 
                       min_degree=0, 
                       avg_clustering_coeff=0, 
                       avg_shortest_path=0, 
                       num_connected_components=0,
                       avg_out_degree=0,
                       avg_in_degree=0,
                       max_out_degree=0,
                       min_out_degree=0,
                       max_in_degree=0,
                       min_in_degree=0):
        self.number_of_nodes = number_of_nodes
        self.number_of_edges = number_of_edges
        self.avg_degree = avg_degree
        self.max_degree = max_degree
        self.min_degree = min_degree
        self.avg_clustering_coeff = avg_clustering_coeff
        self.avg_shortest_path = avg_shortest_path # Largest component
        self.num_connected_components = num_connected_components
        
        # For Directed Graphs
        self.avg_out_degree = avg_out_degree
        self.avg_in_degree = avg_in_degree
        self.max_out_degree = max_out_degree
        self.min_out_degree = min_out_degree
        self.max_in_degree = max_in_degree
        self.min_in_degree = min_in_degree
            
    @classmethod 
    def from_undirected_network(cls, G):
        degrees = [G.degree(n) for n in G.nodes()]
        return Stats(G.number_of_nodes(), 
                          G.number_of_edges(), 
                          np.mean(degrees),  
                          max(degrees), 
                          min(degrees),
                          nx.average_clustering(G),
                          nx.average_shortest_path_length(G.subgraph(sorted(nx.connected_components(G), key=len, reverse=True)[0])),
                          len(list(nx.connected_components(G))))
    
    @classmethod 
    def from_directed_network(cls, G):
        out_degrees = [G.out_degree(d) for d in G.nodes()]
        in_degrees = [G.in_degree(d) for d in G.nodes()]
        
        return Stats(number_of_nodes=G.number_of_nodes(), 
                     number_of_edges=G.number_of_edges(),
                     avg_out_degree=np.mean(out_degrees),
                     avg_in_degree=np.mean(in_degrees),
                     max_out_degree= max(out_degrees),
                     min_degree=min(out_degrees),
                     max_in_degree=max(in_degrees),
                     min_in_degree=min(in_degrees),
                     avg_clustering_coeff=nx.average_clustering(G),
                     avg_shortest_path=nx.average_shortest_path_length(G.subgraph(sorted(nx.strongly_connected_components(G), key=len, reverse=True)[0])),
                     num_connected_components=len(list(nx.strongly_connected_components(G))))
            
    def avg(self, divisor):
        self.number_of_nodes /= divisor
        self.number_of_edges  /= divisor
        self.avg_degree  /= divisor
        self.max_degree /= divisor
        self.min_degree /= divisor
        self.avg_clustering_coeff /= divisor
        self.avg_shortest_path /= divisor
        self.num_connected_components /= divisor 
        self.avg_out_degree /= divisor
        self.avg_in_degree /= divisor
        self.max_out_degree /= divisor
        self.min_out_degree /= divisor
        self.max_in_degree /= divisor
        self.min_in_degree /= divisor
        
    def add(self, stats):
        self.number_of_nodes += stats.number_of_nodes
        self.number_of_edges  += stats.number_of_edges
        self.avg_degree  += stats.avg_degree
        self.max_degree += stats.max_degree
        self.min_degree += stats.min_degree
        self.avg_clustering_coeff += stats.avg_clustering_coeff
        self.avg_shortest_path += stats.avg_shortest_path
        self.num_connected_components += stats.num_connected_components   
        self.avg_out_degree += stats.avg_out_degree   
        self.avg_in_degree += stats.avg_in_degree 
        self.max_out_degree += stats.max_out_degree 
        self.min_out_degree += stats.min_out_degree
        self.max_in_degree += stats.max_in_degree
        self.min_in_degree += stats.min_in_degree 
        
    def to_csv(self, csv_path, is_directed=False):
        if is_directed:
            columns = ['num_of_nodes','num_of_edges','avg_out_deg', 'avg_in_deg', 'max_out_deg', 'min_out_deg', 'max_in_deg', 'min_in_deg', 'avg_clustering_coeff', 'avg_shortest_path', 'num_connected_components']
            df = pd.DataFrame(columns=columns)
            
            new_row = {'num_of_nodes': self.number_of_nodes,'num_of_edges': self.number_of_edges,
                       'avg_out_deg': self.avg_out_degree, 'avg_in_deg': self.avg_in_degree, 
                       'max_out_deg': self.max_out_degree, 'min_out_deg': self.min_out_degree, 
                       'max_in_deg': self.max_in_degree, 'min_in_deg': self.min_in_degree, 
                       'avg_clustering_coeff': self.avg_clustering_coeff, 
                       'avg_shortest_path': self.avg_shortest_path, 
                       'num_connected_components':self.num_connected_components}
            df = df.append(new_row, ignore_index=True)  
            
            df.to_csv(csv_path, index=False)
        else:
            columns = ['num_of_nodes','num_of_edges','avg_deg', 'max_deg', 'min_deg', 'avg_clustering_coeff', 'avg_shortest_path', 'num_connected_components']
            df = pd.DataFrame(columns=columns)
            
            new_row = {'num_of_nodes': self.number_of_nodes,'num_of_edges': self.number_of_edges,
                       'avg_deg': self.avg_degree,  
                       'max_deg': self.max_degree, 'min_deg': self.min_degree, 
                       'avg_clustering_coeff': self.avg_clustering_coeff, 
                       'avg_shortest_path': self.avg_shortest_path, 
                       'num_connected_components':self.num_connected_components}
            df = df.append(new_row, ignore_index=True)  
            
            df.to_csv(csv_path, index=False)