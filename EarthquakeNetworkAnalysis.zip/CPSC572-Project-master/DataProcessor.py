from datetime import timedelta
from math import floor
import pandas as pd
from EarthQuake import EarthQuake
from os.path import exists
import time

class DataProcessor(object):
                        
    # Some Variables
    input_df_columns = ['id','time','latitude', 'longitude', 'mag']
    nodes_df_columns = ['id', 'lat', 'long', 'mag', 'time']
    edges_df_columns = ["source", "target"]
                        
    @classmethod
    def df_from_csv(cls, input_raw_csv : str, output_nodes_csv : str, output_edges_csv : str):
        
        start_time = time.time()
        
        # Some Variables
        input_df_columns = ['id','time','latitude', 'longitude', 'mag']
        nodes_df_columns = ['id', 'lat', 'long', 'mag', 'time']
        edges_df_columns = ["Source", "Target"]
        
        # Prepare temporary data frame
        input_df = pd.read_csv(input_raw_csv, usecols = input_df_columns)
        input_df.rename(columns={"latitude":"lat", "longitude":"long"}, inplace = True)
        input_df['time'] = pd.to_datetime(input_df['time'])
            
        # Create new dataframes for nodes and edges
        nodes_df = None
        if exists(output_nodes_csv): 
            nodes_df = pd.read_csv(output_nodes_csv, usecols = nodes_df_columns)
        else:
            nodes_df = pd.DataFrame(data=input_df[nodes_df_columns])
            nodes_df.to_csv(output_nodes_csv, index=True)
            
        edges_df = pd.DataFrame(columns=edges_df_columns)
        if exists(output_edges_csv): 
            edges_df = pd.read_csv(output_edges_csv, usecols = edges_df_columns)
            return nodes_df, edges_df
            
        # Vars used to hold source and destination earthquakes
        source : EarthQuake = None 
        dest : EarthQuake = None
        
        # Iterate over the data to check if dest earthquake is within influence domain of source earthquake
        # and include them in edges_df if necessary.
        for index, row in input_df.iterrows():
           source = EarthQuake(row['id'], row['time'], row['lat'], row['long'], row['mag'])
           for index2, row2 in input_df.iterrows():
                              
               if(index == index2): continue
               
               dest = EarthQuake(row2['id'], row2['time'], row2['lat'], row2['long'], row2['mag'])
               is_in_domain = source.is_in_influence_domain(dest)
          
               if is_in_domain: 
                   new_row = {'Source':source.id, 'Target':dest.id}
                   edges_df = edges_df.append(new_row, ignore_index=True)  
        
        # Writting it to csv to avoid doing all this computation (unless we have to)
        edges_df.to_csv(output_edges_csv, index=False)
        
        end_time = time.time()
        print(f"\nProcessing Time: {timedelta(seconds=floor(end_time-start_time))}\n")
        
        return nodes_df, edges_df
     