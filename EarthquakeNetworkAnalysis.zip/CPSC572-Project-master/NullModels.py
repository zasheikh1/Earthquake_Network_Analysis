from genericpath import exists
from Stats import Stats
import networkx as nx
from tqdm import tqdm

class NullModels:
    # n = Number of nodes
    # radius = maximum separation between nodes
    # pos = Positions of nodes in the earthquake network in UTM
    # csv_path = Path of where to store stats
    # one_network = Whether to return one network (for plotting degree dist, etc)
    # num_networks = Number of iterations

    @classmethod
    def er_network_stats(cls, G, csv_path, node_info, num_networks=1000):  # Random Geometric Network
        if exists(csv_path): return

        resultStats = Stats()
        for _ in tqdm(range(num_networks), desc="Loading…", ascii=False, ncols=75):
            er_network = cls.er_network(G, node_info)
            stats = Stats.from_directed_network(er_network)
            resultStats.add(stats)

        resultStats.avg(num_networks)
        resultStats.to_csv(csv_path, is_directed=True)


    #generate one random graph using the nodes from another graph G
    @classmethod
    def er_network(cls, G, node_info): # Erdos-Renyi Network
        
        GN = len(G.nodes())
        max_L = GN * (GN - 1)
        actual_L = len(G.edges())
        p = actual_L / max_L

        ER = cls._add_node_info(nx.erdos_renyi_graph(GN, p, directed=True), node_info=node_info)

        return ER


    @classmethod
    def dp_network(cls, degree_list, csv_path, one_network=False, num_networks=1000):
        
        if exists(csv_path): 
            if one_network : return nx.random_degree_sequence_graph(degree_list)
            else:            return None
        
        print(degree_list)
        
        resultStats = Stats()
        for _ in tqdm(range(num_networks), desc="Loading…", ascii=False, ncols=75):
            network = nx.random_degree_sequence_graph(degree_list)
            print(network);
            stats = Stats.from_undirected_network(network)
            resultStats.add(stats)
            
        resultStats.avg(num_networks)
        resultStats.to_csv(csv_path)
        
        if one_network: return nx.random_degree_sequence_graph(degree_list)
        else: return None
    
    # n = Number of nodes 
    # radius = maximum separation between nodes 
    # pos = Positions of nodes in the earthquake network in UTM
    # csv_path = Path of where to store stats
    # one_network = Whether to return one network (for plotting degree dist, etc)
    # num_networks = Number of iterations
    
    # Two Assumptions made in this method:
    #   1. The Radius will be average euclidean distance between nodes in UMT in graph 
    #   2. The output networks will be undirected (we concluded this won't affect the resulting null model) 
    @classmethod
    def rg_network_stats(cls, n, radius, pos, csv_path, node_info, edge_list, num_networks=1000): # Random Geometric Network
        
        if exists(csv_path): return
        
        resultStats = Stats()
        for _ in tqdm(range(num_networks), desc="Loading…", ascii=False, ncols=75):
            network = cls.rg_network(n, radius, pos, node_info, edge_list=edge_list)
            stats = Stats.from_directed_network(network)
            resultStats.add(stats)
            
        resultStats.avg(num_networks)
        resultStats.to_csv(csv_path, is_directed=True)
                
    @classmethod  
    def rg_network(cls, n, radius, pos, node_info, edge_list):  # Return a single Random Geometric DIRECTED network
       
        # Undirected graph
        G = cls._add_node_info(nx.random_geometric_graph(n, radius, pos=pos), node_info=node_info)
        D = nx.DiGraph()
        
        # Add all nodes to Digraph
        for node in G.nodes(data=True):
            D.add_node(node[0], pos=node[1]['pos'], mag=node[1]['mag'], time=node[1]['time'])
        
        # Add connectivity to Digraph
        for node in G.nodes(data=True):
            for neighbor in G.neighbors(node[0]):
                if (node[0], neighbor) in edge_list:
                    D.add_edge(node[0], neighbor)         
        return D 
        
    # OTHER HELPER METHODS */
    
    @classmethod
    def _add_node_info(cls, G, node_info): # G must be an undirected graph
        for item in node_info:
            (id, mag, time) = item
            G.nodes[id]['mag'] = mag
            G.nodes[id]['time'] = time        
        return G