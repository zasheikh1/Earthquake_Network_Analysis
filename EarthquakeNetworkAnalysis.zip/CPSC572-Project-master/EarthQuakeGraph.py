import math
from tkinter import S
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.pyplot as plt
import matplotlib as mpl
import pandas as pd
from os.path import exists
import utm

from Plots import Plots

class EarthQuakeGraph:

    # Basic

    @classmethod
    def create_graph(cls, nodes_df=[], edges_df=[], is_undirected=False):
        G = nx.DiGraph()
        for idx, node in nodes_df.iterrows():
            lat = float(node['lat'])
            long = float(node['long'])
            coords = (lat, long)
            G.add_node(str(node['id']), pos=coords, mag=node['mag'], id=idx)

        for idx, edge in edges_df.iterrows():
            G.add_edge(edge['Source'], edge['Target'])

        if is_undirected:
            return G.to_undirected()
        else:
            return G

    @classmethod
    def show_graph(cls, G):  # Used for quick visualization of the network...
        nx.draw(G, nx.get_node_attributes(G, 'pos'), with_labels=False, node_size=5)
        plt.show()

    # First Research Question

        # Computes a list of pairs of earthquake magnitudes and out-degrees
    @classmethod
    def compute_outdeg_and_maginute(cls, G):
        results = []
        for node in G.nodes(data=True):
            results.append((G.out_degree(node[0]), node[1]['magnitude']))
        return results

        # Computes a list of pairs of earthquake avg clustering coeff and magnitude

    @classmethod
    def compute_outdeg_and_avg_clustering_coeff(cls, G):
        results = []
        for node in G.nodes(data=True):
            results.append((nx.clustering(G, node[0]), node[1]['magnitude']))
        return results

    # Second Research Question
    
    @classmethod
    def calc_average_magnitude(cls, nodes_with_spec_mag, spec_magnitude, G, neighbour_level_original, array_ave_mag_per_level, original_node_list):

        for n in range(len(nodes_with_spec_mag)):
            if n > original_node_list: break;
            neighbour_level = neighbour_level_original
            neighbors = []
            neighbors = [nbr for nbr in G.neighbors(nodes_with_spec_mag[n][0]) if G.nodes[nbr]['mag'] < spec_magnitude]

            # Calculate the average magnitude for all the neighbors
            average_mag = 0
            out_node_list = []
            for element in neighbors:
                average_mag += G.nodes[element]['mag']

                # this converts the format to hold all the node information for each neighbor
                for node in G.nodes(data=True):
                    if node[0] == element:
                        out_node_list.append(node)

            # if more than 1 element divide by elements or if 1 element leave the same
            if len(neighbors) > 1:
                average_mag = round(average_mag / len(neighbors), 2)
            elif len(neighbors) == 1:
                average_mag = average_mag

            if average_mag > 0:
                cls.append_array(average_mag, array_ave_mag_per_level, neighbour_level, n)

            if neighbour_level == 6: break;
            if len(out_node_list) > 0:
                cls.calc_average_magnitude(out_node_list, spec_magnitude, G, (neighbour_level + 1), array_ave_mag_per_level, original_node_list)
            # print("n =", n, array_ave_mag_per_level)

        return array_ave_mag_per_level


    @classmethod
    def append_array(cls, average_mag, array_ave_mag_per_level, neighbour_level, n):
        # add to average value to dictionary
        array_ave_mag_per_level[n][neighbour_level] = average_mag


    @classmethod
    def nodes_with_specific_magnitude(cls, G, csv_path, img_path):
        # find all the nodes with magnitude of x
        spec_magnitude = 5.5
        neighbour_level = 0
        nodes_with_spec_mag = []
        count=0

        #check for mag >= 5.5
        for node in G.nodes(data=True):
            if node[1]['mag'] >= spec_magnitude:
                nodes_with_spec_mag.append(node)

        original_node_list =len(nodes_with_spec_mag)
        rows, cols = (original_node_list+1, 7)
        array_ave_mag_per_level = [[0 for i in range(cols)] for j in range(rows)]

        for quakes in nodes_with_spec_mag:
            array_ave_mag_per_level[count][neighbour_level] = quakes[1]['mag']
            count = count + 1

        if not exists(csv_path):
            array_ave_mag_per_level = EarthQuakeGraph.calc_average_magnitude(nodes_with_spec_mag, spec_magnitude, G,
                                                                             (neighbour_level + 1),
                                                                             array_ave_mag_per_level,
                                                                             original_node_list)
            df=cls.create_datafame(array_ave_mag_per_level, csv_path)
        else:
            df = pd.read_csv(csv_path)
            
        cls.plot_array(df, img_path)


    @classmethod
    def create_datafame(cls, array_ave_mag_per_level, csv_path):
        df = pd.DataFrame(array_ave_mag_per_level)
        df = df.drop(6, axis=1)
        #df = df.drop(11)
        df.columns = ["Origin Node", "Neighbor Level 1 Average", "Neighbor Level 2 Average", "Neighbor Level 3 Average", "Neighbor Level 4 Average", "Neighbor Level 5 Average"]
        df = df.sort_values(by=['Origin Node'], ascending=True)
        df.to_csv(csv_path)
        return df

    # Plots 
    
        # First Research Question
        # data = list of pairs (out degree, mag) of each earthquake in the network

    @classmethod
    def plot_outdeg_vs_magnitude(cls, data):

        # Setting style of plot
        Plots.set_plot_styles_one()

        x = [0, 1, 2, 3, 4, 5, 6, 7]
        out_degrees_sum = [0] * len(x)
        num_of_outdegrees = [0] * len(x)
        y = []

        # Computing average out degree of earthquakes
        # data = list of pairs (out-deg, magnitude)
        for d in data:
            out_degrees_sum[math.floor(d[1])] += d[0]
            num_of_outdegrees[math.floor(d[1])] += 1

        for i in range(0, len(x)):
            y.append(out_degrees_sum[i] / (1 if num_of_outdegrees[i] == 0 else num_of_outdegrees[i]))

        # labels for bars
        tick_label = ['0-1', '1-2', '2-3', '3-4', '4-5', '5-6', '6-7', '7-8']

        # plotting a bar chart
        plt.bar(x, y, tick_label=tick_label, bottom=None, width=0.8, color=['#a30000', '#004777'])
        plt.xlabel('Magnitude')
        plt.ylabel('Avg Out-Degree')
        plt.title('Mainshock Influence on Aftershocks')
        plt.show()
        
        # data = list of pairs (avg clustering coefficient, magnitude) of each earthquake in the network
    @classmethod
    def plot_avg_clustering_coeff_vs_magnitude(cls, data):

        # Setting style of plot
        Plots.set_plot_styles_one()

        x = [0, 1, 2, 3, 4, 5, 6, 7]
        clustering_coeff_sum = [0] * len(x)
        num_of_clustering_coeffs = [0] * len(x)
        y = []

        # Computing average clustering coefficient of earthquakes in specific ranges
        # data = list of pairs (avg clustering coeff, magnitude)
        for d in data:
            clustering_coeff_sum[math.floor(d[1])] += d[0]
            num_of_clustering_coeffs[math.floor(d[1])] += 1

        for i in range(0, len(x)):
            y.append(clustering_coeff_sum[i] / (1 if num_of_clustering_coeffs[i] == 0 else num_of_clustering_coeffs[i]))

        # labels for bars
        tick_label = ['0-1', '1-2', '2-3', '3-4', '4-5', '5-6', '6-7', '7-8']

        # plotting a bar chart
        plt.bar(x, y, tick_label=tick_label, bottom=None, width=0.8, color=['#a30000', '#004777'])
        plt.xlabel('Magnitude')
        plt.ylabel('Avg Clustering Coefficient')
        plt.title('Mainshock Influence Power on Aftershocks')
        plt.show()

          # Second Research Question

    @classmethod
    def plot_array(cls, df, img_path):
        df = df.T

        fig, axes = plt.subplots(nrows=1, ncols=3, sharex=True, figsize=(15, 8))
        ax1, ax2, ax3 = axes.flatten()
        for col in df.columns[0:12]:
            ax1.plot(df[col])

        for col in df.columns[12:24]:
            ax2.plot(df[col])

        for col in df.columns[24:35]:
            ax3.plot(df[col])

        # giving a title to my graph

        fig.suptitle('Average magnitude of neighboring level from the origin node', fontsize=14)
        ax1.set_title('Origin nodes of Magnitude range (5.5 - 5.65)')
        ax2.set_title('Origin nodes of Magnitude range (5.7 - 6.0)')
        ax3.set_title('Origin nodes of Magnitude range (6.0 - 7.60)')

        ax1.tick_params(axis='x', which='both', labelsize=3)
        ax2.tick_params(axis='x', which='both', labelsize=3)
        ax3.tick_params(axis='x', which='both', labelsize=3)

        # Set common labels
        fig.text(0.5, 0.04, 'Neighbor Level', ha='center', va='center')
        fig.text(0.06, 0.5, 'Magnitude', ha='center', va='center', rotation='vertical')

        fig.savefig(img_path)
        
    # OTHER HELPER METHODS 
    
    # Create a csv file (also returns a dict) that contains node ids and their positions in UMT
    # (Universal Transverse Mercator)
    # Returns a dict of {node:umt-coord} 
    @classmethod 
    def to_umt(cls, G, csv_path):
        
        # Check if csv already exists and return that as a dict
        if exists(csv_path): 
            utm_df = pd.read_csv(csv_path, usecols = ['id','utm_easting', 'utm_northing'])
            utm_dict_no_id = {i[0]: (i[1], i[2]) for i in list(utm_df[['utm_easting', 'utm_northing']].itertuples(index=True, name=None))}
            utm_dict_with_id = {i[1]: (i[2], i[3]) for i in list(utm_df[['id', 'utm_easting', 'utm_northing']].itertuples(index=True, name=None))}
            return utm_dict_no_id, utm_dict_with_id
        
        # Create the dataframe because the file does not exist
        utm_df = pd.DataFrame(columns=['utm_easting', 'utm_northing', 'id'])
        
        # Iterate over each node in the network
        for node in G.nodes(data=True):
            # NOTE: We ignore the UTM Zone because earthquakes are close to each other only in the pacific plate.
            utm_coords = utm.from_latlon(node[1]['pos'][0], node[1]['pos'][1])
            new_row = {'id': node[0], 'utm_easting': utm_coords[0], 'utm_northing':utm_coords[1]}
            utm_df = utm_df.append(new_row, ignore_index=True)
        
        # Write the dataframe into csv
        utm_df.to_csv(csv_path)
        
        # Convert the dataframe to a dict and return it
        utm_dict_no_id = {i[0]: (i[1], i[2]) for i in list(utm_df[['utm_easting', 'utm_northing']].itertuples(index=True, name=None))}
        utm_dict_with_id = {i[1]: (i[2], i[3]) for i in list(utm_df[['id', 'utm_easting', 'utm_northing']].itertuples(index=True, name=None))}
        return utm_dict_no_id, utm_dict_with_id
                
    @classmethod
    def avg_euclidean_dist(cls, G, umt_dict, avg_dist_csv):
        
        # Check if csv already exists and return that as a dict
        if exists(avg_dist_csv): 
            return pd.read_csv(avg_dist_csv, usecols = ['avg_euclidean_dist']).iloc[0]['avg_euclidean_dist']

        # Used to store the result
        avg_dist_df = pd.DataFrame(columns=['avg_euclidean_dist'])
        avg_dist_tot = 0

        # For each node find the maximum distance between itself and its neigbors
        # Then find the average of that
        for node in umt_dict.items():
            avg_dist_tmp = 0
            for neighbor in list(G.successors(node[0])):
                neighbor_utm_coords = utm.from_latlon(G.nodes[neighbor]['pos'][0], G.nodes[neighbor]['pos'][1])
                avg_dist_tmp = max(avg_dist_tmp, math.dist([node[1][0], node[1][1]], [neighbor_utm_coords[0], neighbor_utm_coords[1]]))
            avg_dist_tot += avg_dist_tmp
                     
        avg_dist_tot /= len(umt_dict)
        avg_dist_df = avg_dist_df.append({'avg_euclidean_dist':avg_dist_tot}, ignore_index=True)   
        avg_dist_df.to_csv(avg_dist_csv, index=False)
            
        return avg_dist_tot
    
    #csv_path = Path to nodes csv file
    @classmethod
    def get_node_info(cls, csv_path):
        nodes_df = pd.read_csv(csv_path)
        return [(i[0], i[1], i[2]) for i in list(nodes_df[['mag', 'time']].itertuples(index=True, name=None))]
    
    @classmethod
    def get_edge_list(cls, G): # G must be a directed network
        edge_list = []
        for node in G.nodes(data=True):          
            for neighbor in list(G.successors(node[0])):
                edge_list.append((node[1]['id'], G.nodes[neighbor]['id']))  # Means there is an outgoing edge from node to it's neighbor=
        return edge_list